/**
 * @license Highcharts Gantt JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/treegrid
 * @requires highcharts
 *
 * Tree Grid
 *
 * (c) 2016-2019 Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/TreeGrid.js';
