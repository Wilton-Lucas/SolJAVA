/**
 * @license Highcharts JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/accessibility
 * @requires highcharts
 *
 * Accessibility module
 *
 * (c) 2010-2019 Highsoft AS
 * Author: Oystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';

import '../../modules/accessibility/accessibility.js';
