/**
 * @license Highcharts JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/wordcloud
 * @requires highcharts
 *
 * (c) 2016-2019 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/wordcloud.src.js';
