/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author will
 */
public class Servlet extends HttpServlet{
    
    
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response){
        PrintWriter p;
        try {
            p = response.getWriter();
            
            p.print("Ip:"+request.getLocalAddr() + "nome: "+request.getRemoteAddr());
            
            
            
            
        } catch (IOException ex) {
            Logger.getLogger(Servlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}
