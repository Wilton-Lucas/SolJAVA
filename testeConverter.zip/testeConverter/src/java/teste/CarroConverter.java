/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;

import java.io.Serializable;
import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author will
 */
@FacesConverter(value="carroConverter")
public class CarroConverter implements Converter, Serializable{
    List<Carro> lista = new Controller().getTodosCarros();
    @Override
    public Object getAsObject(FacesContext context, UIComponent component,
            String value) {

        if (value == null || value.isEmpty()) {
              Carro unidade = new Carro("carro convertido!");
            return unidade;
        } else {
            
            Carro unidade = new Carro("carro convertido!");
            return unidade;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component,
            Object value) {
        return "para string converter";
    }

}
