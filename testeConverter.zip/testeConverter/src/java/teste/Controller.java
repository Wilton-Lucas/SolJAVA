/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * @author will
 */

@Named("controller")
@SessionScoped
public class Controller implements Serializable{
    
    List<Carro> listaCarros = new ArrayList<>();
    
    List<Carro> todosCarros = new ArrayList<>();
    
    Carro escolha;
    
    
    public Controller(){
        todosCarros.add(new Carro("carro 1"));
        todosCarros.add(new Carro("carro 2"));
        todosCarros.add(new Carro("carro 3"));
        todosCarros.add(new Carro("carro 4"));
       
        
    }

    public List<Carro> getListaCarros() {
        return listaCarros;
    }

    public void setListaCarros(List<Carro> listaCarros) {
        this.listaCarros = listaCarros;
    }

    public List<Carro> getTodosCarros() {
        return todosCarros;
    }

    public void setTodosCarros(List<Carro> todosCarros) {
        this.todosCarros = todosCarros;
    }
    
    
    
    public synchronized  void add() throws InterruptedException{
        System.out.println("****************solicitou add");
        FacesContext.getCurrentInstance().addMessage("", new FacesMessage("Entrou: "+this.toString(),""));
        
            System.out.println("++++ travou add");
            Thread.sleep(5000);
         listaCarros.add(escolha);
            FacesContext.getCurrentInstance().addMessage("", new FacesMessage(listaCarros.toString(),""));
        
        System.out.println("&&&& saiu add");
        FacesContext.getCurrentInstance().addMessage("", new FacesMessage("saiu",""));
    }

    public Carro getEscolha() {
        return escolha;
    }

    public void setEscolha(Carro escolha) {
        this.escolha = escolha;
    }

   

   
    
    
    
}
